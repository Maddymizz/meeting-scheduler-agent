import streamlit as st
from calendar_utils import create_event  # fixed version
from openai import OpenAI
import json
import re
from datetime import datetime

# --- Load OpenAI API key ---
client = OpenAI(api_key="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")  # Replace with your OpenAI API key

st.title("AI-Powered Meeting Scheduler")

# Input fields
calendar_id = st.text_input("Enter your calendar ID", "primary")
meeting_request = st.text_area(
    "Enter meeting request (e.g., 'Schedule a meeting next Tue 3-4pm with alice@example.com')"
)

if st.button("Schedule Meeting"):

    if not meeting_request.strip():
        st.warning("Please enter a meeting request!")
        st.stop()

    # Prompt AI to extract meeting info
    prompt = f"""
You are an AI that extracts meeting details.
Output ONLY valid JSON. No explanation. No text outside the JSON.

Meeting request: "{meeting_request}"

JSON format:
{{
    "date": "YYYY-MM-DD",
    "start_time": "HH:MM",
    "end_time": "HH:MM",
    "email": "someone@example.com"
}}
"""

    # Call OpenAI API safely
    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
            temperature=0
        )
        raw_output = response.choices[0].message.content.strip()
    except Exception as e:
        st.error(f"AI API error: {e}")
        st.stop()

    # Parse JSON safely
    try:
        meeting_info = json.loads(raw_output)
    except:
        match = re.search(r"\{.*\}", raw_output, re.DOTALL)
        if match:
            try:
                meeting_info = json.loads(match.group(0))
            except Exception as e:
                st.error(f"Failed to parse AI JSON output: {e}")
                st.stop()
        else:
            st.error(f"Failed to parse AI output:\n\n{raw_output}")
            st.stop()

    st.subheader("Parsed Meeting Info")
    st.json(meeting_info)

    # Convert strings to datetime objects
    try:
        date_obj = datetime.strptime(meeting_info["date"], "%Y-%m-%d")
        start_time_obj = datetime.strptime(meeting_info["start_time"], "%H:%M").time()
        end_time_obj = datetime.strptime(meeting_info["end_time"], "%H:%M").time()

        start_dt = datetime.combine(date_obj, start_time_obj)
        end_dt = datetime.combine(date_obj, end_time_obj)
        email = meeting_info["email"]

        # Create a summary for the calendar event
        summary = f"Meeting with {email}"

    except Exception as e:
        st.error(f"Error converting date/time: {e}")
        st.stop()

    # Schedule the event using correct arguments
    try:
        create_event(calendar_id, summary, start_dt, end_dt, attendees_emails=[email])
        st.success("Meeting scheduled successfully!")
    except Exception as e:
        st.error(f"Error scheduling meeting: {e}")
