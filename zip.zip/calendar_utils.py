import os
from datetime import datetime
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

# Scopes for Google Calendar
SCOPES = [
    'https://www.googleapis.com/auth/calendar.events',
    'https://www.googleapis.com/auth/calendar.readonly'
]

TOKEN_PATH = 'token.json'          # Path to store user token
CREDENTIALS_PATH = 'credentials.json'  # Path to OAuth credentials


def get_creds():
    """Get Google API credentials, refreshing or authenticating if necessary."""
    creds = None
    if os.path.exists(TOKEN_PATH):
        creds = Credentials.from_authorized_user_file(TOKEN_PATH, SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(CREDENTIALS_PATH, SCOPES)
            creds = flow.run_local_server(port=0)
        # Save the credentials for next time
        with open(TOKEN_PATH, 'w') as token_file:
            token_file.write(creds.to_json())
    return creds


def list_calendars():
    """List all calendars available for the authenticated user."""
    creds = get_creds()
    service = build('calendar', 'v3', credentials=creds)
    result = service.calendarList().list().execute()
    items = result.get('items', [])
    return [(c['id'], c.get('summary', 'No name')) for c in items]


def get_freebusy(calendar_id, start_dt, end_dt):
    """Get busy slots for a calendar between start_dt and end_dt."""
    creds = get_creds()
    service = build('calendar', 'v3', credentials=creds)
    body = {
        "timeMin": start_dt.isoformat(),
        "timeMax": end_dt.isoformat(),
        "timeZone": "UTC",
        "items": [{"id": calendar_id}]
    }
    events = service.freebusy().query(body=body).execute()
    return events['calendars'].get(calendar_id, {}).get('busy', [])


def create_event(calendar_id, summary, start_dt, end_dt, attendees_emails=[]):
    """
    Create a Google Calendar event.
    
    Args:
        calendar_id (str): The ID of the calendar to create the event in.
        summary (str): Event title/summary.
        start_dt (datetime): Start datetime of the event.
        end_dt (datetime): End datetime of the event.
        attendees_emails (list): List of attendee emails.
    """
    creds = get_creds()
    service = build('calendar', 'v3', credentials=creds)
    
    event = {
        'summary': summary,
        'start': {
            'dateTime': start_dt.isoformat(),
            'timeZone': 'UTC'
        },
        'end': {
            'dateTime': end_dt.isoformat(),
            'timeZone': 'UTC'
        },
        'attendees': [{'email': e} for e in attendees_emails],
        'conferenceData': {
            'createRequest': {
                'requestId': 'auto-' + datetime.utcnow().strftime("%Y%m%d%H%M%S")
            }
        }
    }
    
    created_event = service.events().insert(
        calendarId=calendar_id,
        body=event,
        conferenceDataVersion=1
    ).execute()
    
    return created_event
