import streamlit as st
from datetime import datetime, timedelta
from dateparser import parse as dateparse
import pytz
from calendar_utils import list_calendars, get_freebusy, create_event

st.set_page_config(page_title="Meeting Scheduler Agent", layout="centered")

st.title("Meeting Scheduler Agent — Demo")

# Step 1: List calendars
if st.button("Connect / Refresh Calendars"):
    try:
        cals = list_calendars()
        st.session_state['cals'] = cals
        st.success("Calendars loaded")
    except Exception as e:
        st.error(f"Auth / API error: {e}")

cals = st.session_state.get('cals', [])
if cals:
    cal_map = {name: cid for cid, name in cals}
    selected = st.selectbox("Select calendar", options=list(cal_map.keys()))
    cal_id = cal_map[selected]

    # Step 2: Input meeting request (natural language)
    req = st.text_area("Enter meeting request (e.g., 'Schedule a 30 minute meeting next Tue 3-4pm with alice@example.com')", height=100)
    if st.button("Suggest slots"):
        # Very simple parse: extract duration and datetime using dateparser
        # Fallback defaults
        duration_mins = 30
        # naive parsing: look for '30 minute' in text
        import re
        m = re.search(r'(\d{1,3})\s*min', req)
        if m:
            duration_mins = int(m.group(1))
        dt = dateparse(req, languages=['en'])
        if not dt:
            # default to tomorrow 10am
            dt = datetime.now() + timedelta(days=1)
            dt = dt.replace(hour=10, minute=0, second=0, microsecond=0)
        end = dt + timedelta(minutes=duration_mins)
        # check freebusy for a window of 7 days to suggest alternatives
        window_start = (dt - timedelta(days=1)).astimezone(pytz.UTC)
        window_end = (dt + timedelta(days=7)).astimezone(pytz.UTC)
        busy = get_freebusy(cal_id, window_start, window_end)
        st.write("Parsed start:", dt, "duration:", duration_mins, "mins")
        st.write("Busy slots (raw):", busy)
        # Simple suggested slot = parsed dt if not overlapping
        # naive overlap check
        def overlaps(a,b):
            return not (b['end'] <= a['start'] or b['start'] >= a['end'])
        candidate = {'start': dt.astimezone(pytz.UTC).isoformat(), 'end': end.astimezone(pytz.UTC).isoformat()}
        conflict = False
        for b in busy:
            if overlaps({'start': candidate['start'], 'end': candidate['end']}, {'start': b['start'], 'end': b['end']}):
                conflict = True
                break
        if not conflict:
            st.success("Suggested slot is free")
            if st.button("Create event at suggested slot"):
                attendees = []
                import re
                emails = re.findall(r'[\w\.-]+@[\w\.-]+', req)
                attendees = emails
                created = create_event(cal_id, "Meeting via Scheduler Agent", dt.astimezone(pytz.UTC), end.astimezone(pytz.UTC), attendees)
                st.write("Created event:", created.get('htmlLink'))
        else:
            st.warning("Suggested slot conflicts. Try another time or ask for suggestions.")
else:
    st.info("Click Connect / Refresh Calendars to authenticate and list calendars.")
